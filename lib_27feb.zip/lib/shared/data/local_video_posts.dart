List<Map<String, dynamic>> videoPosts = [
  /* {
    'name': 'pareja',
    'videoUrl': 'assets/videos/pareja.mp4',
    'likes': 23230,
    'views': 1523,
  }, */
  {
    'name': 'Toda la Escritura es inspirada por Dios.. 2 Timoteo 3:16-17',
    //'Toda la Escritura es inspirada por Diosy útil para enseñar, para redargüir, para corregir, para instruir en justicia, a fin de que el hombre de Dios sea perfecto, enteramente preparado para toda buena obra. 2 Timoteo 3:16-17',

    'videoUrl': 'assets/videos/palabra.mp4',
    'likes': 24230,
    'views': 1343,
  },
  {
    'name': 'Él les dijo: ¿Por qué teméis.. Mateo 8:26',
    'videoUrl': 'assets/videos/mar_noche.mp4',
    'likes': 21564320,
    'views': 123563,
  },
  {
    'name': 'Jesús le dijo: Yo soy el camino.. Juan 14:6',
    'videoUrl': 'assets/videos/camino.mp4',
    'likes': 320,
    'views': 2300,
  },
  {
    'name': 'te aconsejo que avives el fuego del don de Dios.. 2 Timoteo 1:6',
    'videoUrl': 'assets/videos/fogata.mp4',
    'likes': 3230,
    'views': 31030,
  },
  /* 
  {
    'name': 'pareja2',
    'videoUrl': 'assets/videos/pareja2.mp4',
    'likes': 10,
    'views': 330,
  }, */
  {
    'name': 'Toda potestad me es dada en el cielo.. Mateo 28:18',
    'videoUrl': 'assets/videos/mundo.mp4',
    'likes': 342,
    'views': 3332,
  },
];
